# Contrôle explicite des médias Windows (SMTC). Usage : smtc.ps1 status | pause
# Exécuté par Windows PowerShell 5.1 (WinRT requis).
param([string]$Action = "status")
$ErrorActionPreference = "Stop"
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
  function Await($op, [Type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(4000) | Out-Null; $task.Result }
  [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime] | Out-Null
  $mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  $out = @()
  foreach ($s in $mgr.GetSessions()) {
    $app = $s.SourceAppUserModelId
    if ($app -notmatch '(?i)chrome|msedge|firefox|brave|opera|vivaldi') { continue }
    $st = $s.GetPlaybackInfo().PlaybackStatus.ToString()
    $done = $false
    if ($Action -eq "pause" -and $st -eq "Playing") { $done = Await ($s.TryPauseAsync()) ([bool]) }
    $out += @{ app = $app; status = $st; paused = $done }
  }
  ConvertTo-Json -Compress @{ ok = $true; sessions = @($out) }
} catch {
  ConvertTo-Json -Compress @{ ok = $false; error = $_.Exception.Message }
}
