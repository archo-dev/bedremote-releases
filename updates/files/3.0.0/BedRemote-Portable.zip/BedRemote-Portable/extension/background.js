// BedRemote Universal — service worker. Relais local uniquement : onglets <-> BedRemote sur ce PC (127.0.0.1).
// Le service worker peut être suspendu par le navigateur : tout l'état est reconstruit au réveil
// (les onglets renvoient leur état sur demande) et la connexion WebSocket est rétablie automatiquement.
const VERSION = chrome.runtime.getManifest().version;
const PORT_MIN = 8765, PORT_MAX = 8785;
const BROWSER = (navigator.userAgentData && navigator.userAgentData.brands || []).some(b => /Edge/i.test(b.brand)) ? 'Edge'
  : (/Edg\//.test(navigator.userAgent) ? 'Edge' : 'Chrome');

let ws = null, wsReady = false, connecting = false, lastPort = 0, pingTimer = null, idleSince = 0;
let library = null;
const frames = new Map();       // "tab:frame" -> dernier état
const tabProfiles = new Map();  // tab -> id de profil détecté par marqueurs (Jellyfin, Plex local…)

// ---------- Bibliothèque de profils (fichier local de l'extension, données uniquement) ----------
let userProfiles = [];   // profils personnels de l'utilisateur, validés par BedRemote (données uniquement, jamais de code)
async function lib() {
  if (!library) {
    let base = [];
    try { base = (await (await fetch(chrome.runtime.getURL('sites.json'))).json()).profiles || []; } catch (e) {}
    base = base.filter(p => p && typeof p.id === 'string' && Array.isArray(p.domains || []));
    const taken = new Set(userProfiles.flatMap(p => p.domains || []));
    library = [...userProfiles, ...base.filter(p => !(p.domains || []).some(d => taken.has(d)) || p.id === 'generic')];
  }
  return library;
}
function domainMatch(host, d) {
  host = (host || '').toLowerCase();
  if (d.endsWith('.*')) return new RegExp('(^|\\.)' + d.slice(0, -2).replace(/[.]/g, '\\.') + '\\.[a-z]{2,6}(\\.[a-z]{2})?$').test(host);
  return host === d || host.endsWith('.' + d);
}
function matchProfile(profiles, host, scheme) {
  const generic = profiles.find(p => p.id === 'generic') || { id: 'generic', name: 'Lecteur HTML5 générique', capabilities: {} };
  if (scheme === 'file') return profiles.find(p => (p.schemes || []).includes('file')) || generic;
  let best = null, len = 0;
  for (const p of profiles) for (const d of p.domains || []) {
    if (domainMatch(host, d) && d.length > len) { best = p; len = d.length; }
  }
  return best || generic;
}
async function profileFor(tab, host, scheme) {
  const profiles = await lib();
  if (tab && tabProfiles.has(tab.id)) { const p = profiles.find(x => x.id === tabProfiles.get(tab.id)); if (p) return p; }
  let top = null;
  try { if (tab && tab.url) { const u = new URL(tab.url); top = matchProfile(profiles, u.hostname, u.protocol.replace(':', '')); } } catch (e) {}
  if (top && top.id !== 'generic') return top;
  return matchProfile(profiles, host, scheme);
}
const slim = p => ({ id: p.id, name: p.name, capabilities: p.capabilities || {}, selectors: p.selectors || {}, ads: p.ads || [],
  shadow: !!p.shadow, genericNext: p.genericNext !== false, validation: p.validation || 'unvalidated', media: p.media || 'video' });

// ---------- Messages des onglets ----------
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !msg || typeof msg !== 'object') return;
  if (!sender.tab) {  // fenêtre de l'extension (popup)
    if (msg.type === 'status') {
      ensureWs();
      const players = [...frames.values()].reduce((n, f) => n + f.players.length, 0);
      reply({ connected: !!(ws && wsReady), port: lastPort, browser: BROWSER, version: VERSION, players, pending: pendingApproval,
        server: serverVersion, access: grantedAll ? 'all' : (grantedOrigins.length ? 'some' : 'none'),
        sites: [...new Set([...frames.values()].filter(f => f.players.length).map(f => f.siteName))] });
    }
    return;
  }
  const tab = sender.tab, key = tab.id + ':' + (sender.frameId || 0);
  if (msg.type === 'hello') {
    (async () => {
      const p = await profileFor(tab, msg.host, msg.scheme);
      const detectable = p.id === 'generic' ? (await lib()).filter(x => x.detect).map(x => ({ id: x.id, detect: x.detect })) : null;
      reply({ profile: slim(p), detectable });
    })();
    return true;
  }
  if (msg.type === 'detected') {
    (async () => {
      const p = (await lib()).find(x => x.id === msg.id);
      if (!p) return;
      tabProfiles.set(tab.id, p.id);
      chrome.tabs.sendMessage(tab.id, { type: 'profile', profile: slim(p) }, () => void chrome.runtime.lastError);
    })();
    return;
  }
  if (msg.type === 'frame') {
    (async () => {
      const p = await profileFor(tab, msg.host, msg.scheme);
      const st = { tab: tab.id, frame: sender.frameId || 0, top: !!msg.top, host: String(msg.host || '').slice(0, 120),
        active: !!tab.active, vis: !!msg.vis, discarded: !!tab.discarded, site: p.id, siteName: p.name, validation: p.validation || 'unvalidated',
        caps: p.capabilities || {}, players: Array.isArray(msg.players) ? msg.players.slice(0, 6) : [], a: msg.a || null, tabTitle: '' };
      if (!st.players.length && !st.a) frames.delete(key); else frames.set(key, st);
      // Lecteur dans une iframe : on demande au cadre principal son titre et ses boutons (épisode suivant, intro…)
      if (st.frame !== 0 && st.players.length && !frames.has(tab.id + ':0')) {
        chrome.tabs.sendMessage(tab.id, { type: 'report', a: true }, { frameId: 0 }, () => void chrome.runtime.lastError);
      }
      if (st.players.length) idleSince = 0;
      sendWs({ type: 'frame', f: st });
      ensureWs();
    })();
    return;
  }
  if (msg.type === 'ended') {
    sendWs({ type: 'ended', tab: tab.id, frame: sender.frameId || 0, s: msg.s });
    return;
  }
  if (msg.type === 'bye') {
    if (frames.delete(key)) sendWs({ type: 'gone', tab: tab.id, frame: sender.frameId || 0 });
  }
});
chrome.tabs.onRemoved.addListener(tabId => {
  tabProfiles.delete(tabId);
  for (const k of [...frames.keys()]) if (k.startsWith(tabId + ':')) frames.delete(k);
  sendWs({ type: 'tabgone', tab: tabId });
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.sendMessage(tabId, { type: 'report' }, () => void chrome.runtime.lastError);
});

// ---------- Connexion à BedRemote (WebSocket local, maintient le service worker actif tant qu'une vidéo existe) ----------
function sendWs(obj) {
  if (ws && wsReady) { try { ws.send(JSON.stringify(obj)); } catch (e) {} }
}
// ---------- Appairage : l'identifiant de l'extension ne suffit pas ----------
// Premier contact : BedRemote délivre un secret propre à cette installation (automatiquement pour l'extension
// officielle, après accord explicite dans BedRemote pour un autre identifiant, ex. celui attribué par une boutique).
// Ensuite chaque connexion prouve la possession du secret (HMAC-SHA256 d'un défi aléatoire du serveur).
let pairing = null, pendingApproval = false, serverVersion = '';
async function loadPairing() {
  if (!pairing) { try { pairing = (await chrome.storage.local.get('pairing')).pairing || {}; } catch (e) { pairing = {}; } }
  return pairing;
}
async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join('');
}
async function tryPort(port) {
  const pr = await loadPairing();
  const known = pr[port] || pr.any || null;
  return new Promise(resolve => {
    let done = false, s;
    const finish = ok => { if (done) return; done = true; clearTimeout(t); if (!ok) { try { s.close(); } catch (e) {} } resolve(ok ? s : null); };
    const t = setTimeout(() => finish(false), 3000);
    try { s = new WebSocket(`ws://127.0.0.1:${port}/ext/ws`); } catch (e) { return finish(false); }
    s.onopen = () => s.send(JSON.stringify({ type: 'hello', app: 'BedRemote', proto: 3, ext: VERSION, browser: BROWSER, client: known && known.client || null }));
    s.onmessage = async ev => {
      let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.type === 'challenge' && known && typeof m.nonce === 'string') {
        s.send(JSON.stringify({ type: 'auth', mac: await hmacHex(known.secret, m.nonce) }));
      } else if (m.type === 'paired' && typeof m.client === 'string' && typeof m.secret === 'string') {
        pairing = Object.assign({}, pr, { any: { client: m.client, secret: m.secret } });
        try { await chrome.storage.local.set({ pairing }); } catch (e) {}
      } else if (m.type === 'pending') {
        pendingApproval = true; finish(false);
      } else if (m.type === 'unpaired') {   // secret révoqué dans BedRemote : nouvel appairage au prochain essai
        pairing = {}; try { await chrome.storage.local.remove('pairing'); } catch (e) {} finish(false);
      } else if (m.type === 'welcome' && m.app === 'BedRemote') {
        pendingApproval = false; serverVersion = String(m.version || '');
        if (Array.isArray(m.userProfiles)) { userProfiles = m.userProfiles.filter(p => p && typeof p.id === 'string' && /^user-/.test(p.id)); library = null; }
        finish(true);
      }
    };
    s.onerror = () => finish(false);
    s.onclose = () => finish(false);
  });
}
let lastFail = 0;
async function ensureWs() {
  if ((ws && ws.readyState <= 1) || connecting) return;
  if (Date.now() - lastFail < 8000) return;   // BedRemote fermé : nouvel essai dans quelques secondes
  connecting = true;
  lastFail = Date.now();
  try {
    if (!lastPort) { try { lastPort = (await chrome.storage.local.get('port')).port || 0; } catch (e) {} }
    const order = [lastPort, ...Array.from({ length: PORT_MAX - PORT_MIN + 1 }, (_, i) => PORT_MIN + i)].filter((p, i, a) => p && a.indexOf(p) === i);
    for (const port of order) {
      const s = await tryPort(port);
      if (!s) continue;
      ws = s; wsReady = true; lastPort = port; lastFail = 0;
      try { chrome.storage.local.set({ port }); } catch (e) {}
      s.onmessage = ev => onServer(ev.data);
      s.onclose = s.onerror = () => { if (ws === s) { ws = null; wsReady = false; clearInterval(pingTimer); } };
      clearInterval(pingTimer);
      pingTimer = setInterval(keepalive, 20000);
      for (const st of frames.values()) sendWs({ type: 'frame', f: st });
      requestReports();
      return;
    }
  } finally { connecting = false; }
}
function keepalive() {
  // Aucun lecteur depuis 5 min : on ferme la connexion et le navigateur peut endormir l'extension (conso ~0).
  const hasPlayers = [...frames.values()].some(f => f.players.length);
  if (!hasPlayers) { idleSince = idleSince || Date.now(); if (Date.now() - idleSince > 300000) { try { ws.close(); } catch (e) {} return; } }
  sendWs({ type: 'ping' });
}
function requestReports() {
  chrome.tabs.query({}, tabs => {
    for (const t of tabs || []) if (!t.discarded) chrome.tabs.sendMessage(t.id, { type: 'report' }, () => void chrome.runtime.lastError);
  });
}

function onServer(data) {
  let m; try { m = JSON.parse(data); } catch (e) { return; }
  if (m.type !== 'cmd' || typeof m.tab !== 'number') return;
  const allowed = ['play', 'pause', 'playpause', 'seek', 'seek_rel', 'volume', 'mute', 'rate', 'next', 'prev', 'skip'];
  if (!allowed.includes(m.cmd)) return sendWs({ type: 'ack', rid: m.rid, ok: false, msg: 'Commande refusée' });
  chrome.tabs.sendMessage(m.tab, { type: 'cmd', n: m.n, cmd: m.cmd, value: m.value, kind: m.kind }, { frameId: m.frame | 0 }, r => {
    const err = chrome.runtime.lastError;
    if (err || !r) return sendWs({ type: 'ack', rid: m.rid, ok: false, msg: 'Onglet inaccessible (fermé, suspendu ou rechargé)' });
    sendWs(Object.assign({ type: 'ack', rid: m.rid }, r));
  });
}

// Réveil périodique de secours (si le service worker a été suspendu malgré tout).
chrome.alarms.create('bedremote', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(() => { if (frames.size) ensureWs(); else requestReports(); });
chrome.runtime.onStartup.addListener(() => requestReports());
// ---------- Accès aux sites : permissions facultatives accordées par l'utilisateur ----------
// Aucun site n'est lu tant que l'utilisateur n'a pas accordé l'accès (tous les sites, ou site par site).
// Le moteur n'est injecté que sur les origines accordées.
let grantedAll = false, grantedOrigins = [];
async function syncRegistration(injectExisting) {
  const perms = await chrome.permissions.getAll();
  const origins = (perms.origins || []).filter(o => !/^http:\/\/127\.0\.0\.1\//.test(o));
  grantedAll = origins.some(o => o === '<all_urls>' || o === '*://*/*');
  grantedOrigins = origins;
  try { await chrome.scripting.unregisterContentScripts({ ids: ['bedremote'] }); } catch (e) {}
  if (!origins.length) return;
  await chrome.scripting.registerContentScripts([{ id: 'bedremote', js: ['content.js'], matches: grantedAll ? ['<all_urls>'] : origins,
    allFrames: true, matchOriginAsFallback: true, runAt: 'document_idle', persistAcrossSessions: true }]).catch(() => {});
  if (injectExisting) {
    // Deux passes : les onglets qui se chargent PENDANT l'enregistrement ne reçoivent pas le script enregistré.
    // (content.js ignore une seconde injection dans la même page.)
    const injectAll = () => chrome.tabs.query({}, tabs => {
      for (const t of tabs || []) {
        if (t.discarded) continue;
        chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['content.js'] }, () => void chrome.runtime.lastError);
      }
    });
    injectAll();
    setTimeout(injectAll, 3000);
  }
}
chrome.permissions.onAdded.addListener(() => syncRegistration(true));
chrome.permissions.onRemoved.addListener(() => syncRegistration(false));
chrome.runtime.onInstalled.addListener(async details => {
  await syncRegistration(true);
  // Première installation sans accès : page d'accueil expliquant et demandant l'autorisation (geste de l'utilisateur).
  if (details.reason === 'install' && !grantedOrigins.length) chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
});
syncRegistration(false);
requestReports();
ensureWs();
