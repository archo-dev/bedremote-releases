// BedRemote Universal — moteur de contrôle vidéo (script de contenu, tous les cadres).
// Ne lit ni cookies, ni identifiants, ni historique. N'envoie que l'état des lecteurs au service worker
// de l'extension, qui le relaie uniquement à BedRemote sur ce PC (127.0.0.1).
(() => {
  if (window.__bedremote2) return;
  window.__bedremote2 = true;

  const TOP = window === window.top;
  let profile = null;           // profil reçu du service worker (jamais de code exécuté)
  let started = false, dead = false;
  const ids = new WeakMap();
  let seq = 0;
  const tracked = new Set();
  let lastHref = location.href, lastSent = '', lastSentAt = 0, sendTimer = null;
  let adapterCache = { ts: 0, val: null };
  let forceA = false;   // cadre principal : rapporte titre/boutons quand le lecteur est dans une iframe

  // ---------- Utilitaires ----------
  const norm = s => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’`]/g, "'")
    .replace(/\s+/g, ' ').trim().toLowerCase();
  function hash(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0; return h.toString(36); }
  const num = x => (isFinite(x) ? Math.round(x * 100) / 100 : -1);

  function visible(el) {
    if (!el || !el.isConnected || el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && +cs.opacity > 0.05;
  }
  function label(el) {
    const t = el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || '';
    return norm(t);
  }

  // Libellés reconnus (comparaison exacte ou en début de libellé court, sans accents)
  const INTRO_RE = [
    /^(passer|ignorer|sauter|zapper)( l'| le | la | les | )?(intro|introduction|generique( de debut| d'ouverture)?|opening|ouverture)\b/,
    /^skip( the)? (intro|opening|op|title sequence)\b/, /^(intro|vorspann) uberspringen$/, /^(saltar|omitir) (la )?(intro|introduccion|cabecera)\b/,
    /^salta (l')?(intro|sigla)\b/, /^pular (a )?(abertura|introducao)\b/,
  ];
  const RECAP_RE = [/^(passer|ignorer|sauter)( l'| le | la | )?(recap|recapitulatif|resume|precedemment)\b/, /^skip( the)? (recap|summary)\b/,
    /^(ruckblick|zusammenfassung) uberspringen$/, /^(saltar|omitir) (el )?resumen\b/, /^salta (il )?riassunto\b/, /^pular (o )?resumo\b/];
  const AD_RE = /\b(ad|ads|advert|advertisement|advertising|pub|publicite|publicites|annonce|annonces|werbung|anuncio|anuncios|pubblicita|sponsor|sponsorise|sponsored)\b/;
  const NEXT_RE = /^(episode suivant|prochain episode|lire l'episode suivant|next episode|play next episode|nachste folge|naechste folge|siguiente episodio|episodio successivo|proximo episodio)$/;
  const PREV_RE = /^(episode precedent|previous episode|vorherige folge|episodio anterior|episodio precedente)$/;
  const AD_FRAME_RE = /(^|\.)(imasdk\.googleapis\.com|doubleclick\.net|googlesyndication\.com|adnxs\.com|spotxchange\.com|teads\.tv|smartadserver\.com|moatads\.com|innovid\.com)$/;

  function classifySkip(el) {
    const l = label(el);
    if (!l || l.length > 48 || AD_RE.test(l)) return null;
    if (INTRO_RE.some(r => r.test(l))) return 'intro';
    if (RECAP_RE.some(r => r.test(l))) return 'recap';
    return null;
  }

  function q(sels) {
    for (const s of sels || []) {
      let el; try { el = document.querySelector(s); } catch (e) { continue; }  // sélecteur invalide : ignoré
      if (el && visible(el)) return el;
    }
    return null;
  }

  // ---------- Détection des vidéos ----------
  function shadowVideos(limit) {
    const out = [], stack = [document.documentElement];
    let n = 0;
    while (stack.length && n < limit) {
      const node = stack.pop(); n++;
      if (node.shadowRoot) { node.shadowRoot.querySelectorAll('video, audio').forEach(v => out.push(v)); stack.push(...node.shadowRoot.children); }
      if (node.children) for (const c of node.children) stack.push(c);
    }
    return out;
  }
  let lastShadowScan = 0;
  function scan() {
    const found = new Set(document.querySelectorAll('video, audio'));
    if (!found.size && (profile && profile.shadow) && Date.now() - lastShadowScan > 8000) {
      lastShadowScan = Date.now();
      shadowVideos(4000).forEach(v => found.add(v));
    }
    for (const v of tracked) if (!v.isConnected) { tracked.delete(v); }
    for (const v of found) if (!tracked.has(v)) attach(v);
    for (const v of tracked) if (!found.has(v) && !v.getRootNode().host) tracked.delete(v);
  }
  const MEDIA_EVENTS = ['play', 'playing', 'pause', 'ended', 'seeked', 'volumechange', 'ratechange', 'durationchange',
    'loadedmetadata', 'waiting', 'emptied', 'loadstart'];
  function attach(v) {
    tracked.add(v);
    if (!ids.has(v)) ids.set(v, ++seq);
    for (const e of MEDIA_EVENTS) v.addEventListener(e, onMedia, { passive: true });
  }
  function onMedia(e) {
    const v = e.target;
    if (e.type === 'ended') { report(true); endedSignal(v); return; }
    if (e.type === 'play' || e.type === 'playing') v.__brLastPlay = Date.now();
    report(e.type === 'play' || e.type === 'pause' || e.type === 'emptied' || e.type === 'loadedmetadata');
  }
  // Découverte de lecteurs ajoutés dynamiquement : les événements média ne remontent pas, on les capture.
  for (const ev of ['loadstart', 'play', 'loadedmetadata']) {
    document.addEventListener(ev, e => { if (e.target instanceof HTMLMediaElement && !tracked.has(e.target)) { attach(e.target); report(true); } }, true);
  }

  function techOf(v) {
    const c = v.closest('.video-js, .jwplayer, .plyr, .shaka-video-container, .flowplayer, .fp-player, .mejs__container, .mejs-container');
    if (c) {
      const k = c.className;
      if (/video-js/.test(k)) return 'Video.js'; if (/jwplayer/.test(k)) return 'JW Player'; if (/plyr/.test(k)) return 'Plyr';
      if (/shaka/.test(k)) return 'Shaka Player'; if (/flowplayer|fp-player/.test(k)) return 'Flowplayer'; if (/mejs/.test(k)) return 'MediaElement.js';
    }
    if ((v.currentSrc || '').startsWith('blob:')) return 'HTML5 + MSE (hls.js / dash.js / Shaka)';
    if (v.srcObject) return 'HTML5 (flux)';
    return 'HTML5';
  }

  function isAd(v) {
    if (AD_FRAME_RE.test(location.hostname)) return true;
    for (const s of (profile && profile.ads) || []) { try { if (v.closest(s) || document.querySelector(s)) return true; } catch (e) {} }
    let el = v, depth = 0;
    while (el && depth < 4) {
      const k = ((el.id || '') + ' ' + (typeof el.className === 'string' ? el.className : '')).toLowerCase();
      if (/(^|[\s_-])(ad|ads|advert|preroll|midroll|ima-ad|adcontainer|ad-container)([\s_-]|$)/.test(k)) return true;
      el = el.parentElement; depth++;
    }
    return false;
  }

  function seekRange(v) {
    try { const s = v.seekable; if (s && s.length) return [num(s.start(0)), num(s.end(s.length - 1))]; } catch (e) {}
    return [0, num(v.duration)];
  }

  function snap(v) {
    const s = rawSnap(v);
    if (s.d > 0 && !s.live) v.__brLast = s;   // dernier état valide (utile si le site change la source dès la fin)
    return s;
  }
  function endSnap(v) {
    const s = rawSnap(v), last = v.__brLast;
    if (last && (!(s.d > 0) || s.key !== last.key)) return Object.assign({}, last, { t: last.d, ended: true, paused: true });
    return s;
  }
  function rawSnap(v) {
    const r = v.getBoundingClientRect();
    const d = v.duration, live = d === Infinity || (v.srcObject && !isFinite(d));
    const [ss, se] = seekRange(v);
    return {
      n: ids.get(v), t: num(v.currentTime), d: live ? -1 : num(d), live: !!live,
      paused: v.paused, ended: v.ended, loading: !v.paused && (v.readyState < 3 || v.seeking),
      rate: v.playbackRate, vol: Math.round(v.volume * 100) / 100, muted: v.muted,
      w: Math.round(r.width), h: Math.round(r.height),
      onscreen: r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth,
      loop: v.loop, ad: isAd(v), ss, se, tech: techOf(v),
      lp: v.__brLastPlay || 0,
      media: (v instanceof HTMLAudioElement || (v.readyState > 0 && !v.videoWidth && !v.srcObject)) ? 'audio' : 'video',
      key: hash(location.pathname + location.search + '|' + (v.currentSrc && !v.currentSrc.startsWith('blob:') ? v.currentSrc : '') + '|' + Math.round(isFinite(d) ? d : 0)),
    };
  }

  // ---------- Adaptateur de site (sélecteurs déclaratifs + libellés exacts) ----------
  function cleanTitle(t) {
    t = (t || '').replace(/\s+/g, ' ').trim();
    if (profile && profile.name) {
      const re = new RegExp('\\s*[|\\-–—:]\\s*(' + profile.name.split(/\s*\/\s*/).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\s*$', 'i');
      t = t.replace(re, '');
    }
    return t.replace(/^\(\d+\)\s*/, '').slice(0, 140);
  }
  function parseEpisode(s) {
    s = s || '';
    let m = s.match(/\bS(\d{1,2})\s*[:.]?\s*E(\d{1,3})\b/i) || s.match(/saison\s*(\d{1,2})\D{1,12}[ée]pisode\s*(\d{1,3})/i)
      || s.match(/season\s*(\d{1,2})\D{1,12}episode\s*(\d{1,3})/i);
    if (m) return [+m[1], +m[2]];
    m = s.match(/\b(?:[ée]pisode|ep\.?|épisode)\s*(\d{1,3})\b/i);
    return m ? [null, +m[1]] : [null, null];
  }
  function playerContainer() {
    let best = null, area = 0;
    for (const v of tracked) { const r = v.getBoundingClientRect(); if (r.width * r.height > area) { area = r.width * r.height; best = v; } }
    if (!best) return null;
    let el = best.parentElement;
    for (let i = 0; i < 6 && el && el.parentElement && el.parentElement !== document.body; i++) el = el.parentElement;
    return el;
  }
  function textButtons(root, re, limit) {
    if (!root) return null;
    const els = root.querySelectorAll('button, [role="button"], a');
    for (let i = 0; i < els.length && i < limit; i++) { const el = els[i]; const l = label(el); if (l.length <= 48 && re.test(l) && visible(el)) return el; }
    return null;
  }
  // Mode B : chapitres officiels exposés par le lecteur (pistes « chapters ») nommés comme un générique/récapitulatif.
  function chapterSkip() {
    for (const v of tracked) {
      if (v.paused || !v.textTracks) continue;
      for (const tr of v.textTracks) {
        if (tr.kind !== 'chapters') continue;
        if (tr.mode === 'disabled') tr.mode = 'hidden';
        for (const c of tr.cues || []) {
          if (v.currentTime >= c.startTime && v.currentTime < c.endTime - 1) {
            const l = norm(c.text || '');
            if (AD_RE.test(l) || l.length > 60) continue;
            if (/^(intro|introduction|opening|generique|generique de debut|credits d'ouverture|title sequence)$/.test(l)) return [v, 'intro', c.endTime];
            if (/^(recap|recapitulatif|resume|previously|precedemment)$/.test(l)) return [v, 'recap', c.endTime];
          }
        }
      }
    }
    return null;
  }
  function findSkip() {
    const sel = profile && profile.selectors || {};
    let el = q(sel.skipIntro); if (el && !AD_RE.test(label(el))) return [el, 'intro'];
    el = q(sel.skipRecap); if (el && !AD_RE.test(label(el))) return [el, 'recap'];
    // Libellés exacts : dans le conteneur du lecteur si une vidéo est ici, sinon dans le document (cadre principal d'un site profilé)
    const root = playerContainer() || (profile && profile.id !== 'generic' ? document.body : null);
    if (root) {
      const els = root.querySelectorAll('button, [role="button"]');
      for (let i = 0; i < els.length && i < 300; i++) {
        const k = classifySkip(els[i]);
        if (k && visible(els[i])) return [els[i], k];
      }
    }
    const ch = chapterSkip();
    return ch ? [ch[0], ch[1], ch[2]] : null;
  }
  function findNav(kind) {
    const sel = profile && profile.selectors || {};
    const el = q(kind === 'next' ? sel.next : sel.prev);
    if (el) return el;
    if (profile && profile.genericNext === false) return null;
    const root = playerContainer() || (TOP ? document.body : null);
    return textButtons(root, kind === 'next' ? NEXT_RE : PREV_RE, 400);
  }
  function adapter() {
    if (Date.now() - adapterCache.ts < 900 && adapterCache.val) return adapterCache.val;
    const sel = profile && profile.selectors || {};
    const skip = findSkip();
    let title = '';
    const tEl = q(sel.title);
    if (tEl) title = tEl.textContent;
    let ms = null;
    try { ms = navigator.mediaSession && navigator.mediaSession.metadata; } catch (e) {}
    if (!title && ms && ms.title) title = ms.title;
    if (!title && TOP) title = document.title;
    let epText = (q(sel.episode) || {}).textContent || '';
    const [season, episode] = parseEpisode(epText + ' ' + title + ' ' + (ms && ms.album || ''));
    const val = { next: !!findNav('next'), prev: !!findNav('prev'), skip: skip ? skip[1] : null,
      skipSrc: skip && skip.length > 2 ? 'chapters' : 'button',
      title: cleanTitle(title), sub: cleanTitle(epText || (ms && ms.artist) || ''), season, episode,
      artist: (ms && ms.artist || '').slice(0, 100), album: (ms && ms.album || '').slice(0, 100) };
    adapterCache = { ts: Date.now(), val };
    return val;
  }

  // ---------- Rapport au service worker ----------
  function payload() {
    const players = [];
    for (const v of tracked) {
      if (!v.isConnected) continue;
      if (!v.currentSrc && !v.srcObject && v.readyState === 0) continue;  // élément vide (miniature non chargée)
      if (v instanceof HTMLAudioElement && !(v.duration > 1 || !v.paused)) continue;  // sons d'interface : ignorés
      players.push(snap(v));
      if (players.length >= 6) break;
    }
    const profiled = profile && profile.id !== 'generic';
    const a = (players.length || (TOP && (profiled || forceA))) ? adapter() : null;
    return { type: 'frame', top: TOP, host: location.hostname, scheme: location.protocol.replace(':', ''),
      vis: document.visibilityState === 'visible', players, a };
  }
  function send(msg) {
    if (dead) return;
    try {
      chrome.runtime.sendMessage(msg, () => { void chrome.runtime.lastError; });
    } catch (e) { dead = true; }  // extension rechargée : ce script est orphelin
  }
  function report(urgent) {
    if (urgent) { clearTimeout(sendTimer); sendTimer = setTimeout(flush, 60); }
    else if (!sendTimer) sendTimer = setTimeout(flush, 250);
  }
  function flush() {
    sendTimer = null;
    const p = payload();
    if (!p.players.length && !p.a && !lastSent) return;       // rien à signaler : aucune activité
    const sig = JSON.stringify(p);
    if (sig === lastSent && Date.now() - lastSentAt < 4000) return;
    lastSent = p.players.length || p.a ? sig : ''; lastSentAt = Date.now();
    send(p);
  }
  function endedSignal(v) {
    send({ type: 'ended', s: endSnap(v) });
  }

  // ---------- Commandes ----------
  function byId(n) { for (const v of tracked) if (ids.get(v) === n) return v; return null; }
  function clamp(x, a, b) { return Math.min(b, Math.max(a, x)); }
  function press(el) {
    el.scrollIntoView && el.scrollIntoView({ block: 'nearest' });
    for (const t of ['pointerover', 'pointerenter', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
      try { el.dispatchEvent(new (t.startsWith('pointer') ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, composed: true })); } catch (e) {}
    }
    el.click();
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Reprise vérifiée : certains lecteurs (ex. PeerTube/Video.js) annulent une reprise faite pendant un chargement ;
  // on attend la fin du chargement, on vérifie, puis on réessaie une fois.
  async function playVerified(v) {
    for (let i = 0; i < 2; i++) {
      try { await v.play(); } catch (e) { if (i) return { ok: false, msg: 'Lecture refusée par le navigateur (interaction requise sur la page)' }; }
      await sleep(i ? 900 : 600);
      if (!v.paused) return { ok: true, msg: 'Lecture' };
      if (v.seeking || v.readyState < 3) await new Promise(r => { const t = setTimeout(r, 2500); v.addEventListener('canplay', () => { clearTimeout(t); r(); }, { once: true }); });
    }
    return { ok: false, msg: 'Le lecteur du site a remis la vidéo en pause' };
  }
  // Volume vérifié : certains lecteurs (ex. Vimeo) réimposent leur propre volume juste après ; on réapplique une fois.
  async function volumeVerified(v, x) {
    for (let i = 0; i < 3; i++) {
      v.volume = x; if (x > 0) v.muted = false;
      await sleep(350);
      if (Math.abs(v.volume - x) < 0.02 && (x === 0 || !v.muted)) return { ok: true, msg: 'Volume lecteur ' + Math.round(x * 100) + ' %' };
    }
    return { ok: false, msg: 'Le lecteur du site impose son propre volume : utilisez le volume Windows' };
  }
  async function exec(m) {
    const caps = (profile && profile.capabilities) || {};
    if (m.cmd === 'next' || m.cmd === 'prev') {
      const el = findNav(m.cmd); if (!el) return { ok: false, msg: 'Bouton introuvable sur la page' };
      press(el); adapterCache.ts = 0; return { ok: true, msg: m.cmd === 'next' ? 'Épisode suivant' : 'Épisode précédent' };
    }
    if (m.cmd === 'skip') {
      const s = findSkip(); if (!s) return { ok: false, msg: 'Aucun bouton « passer » affiché' };
      if (m.kind && s[1] !== m.kind && m.kind !== 'any') return { ok: false, msg: 'Bouton différent' };
      if (s.length > 2) {  // chapitre officiel : on se place à sa fin
        s[0].currentTime = s[2]; adapterCache.ts = 0;
        return { ok: true, msg: (s[1] === 'recap' ? 'Récapitulatif' : 'Générique') + ' passé (chapitre)', kind: s[1] };
      }
      press(s[0]); adapterCache.ts = 0; return { ok: true, msg: s[1] === 'recap' ? 'Récapitulatif passé' : 'Générique passé', kind: s[1] };
    }
    const v = byId(m.n);
    if (!v || !v.isConnected) return { ok: false, msg: 'Lecteur introuvable (remplacé ?)' };
    const val = +m.value;
    switch (m.cmd) {
      case 'play': return await playVerified(v);
      case 'pause': v.pause(); return { ok: true, msg: 'Pause' };
      case 'playpause':
        if (v.paused || v.ended) return await playVerified(v);
        v.pause(); return { ok: true, msg: 'Pause' };
      case 'seek_rel': case 'seek': {
        if (caps.seek === false) return { ok: false, msg: 'Recherche directe non prise en charge sur ce site', unsupported: true };
        const [a, b] = seekRange(v);
        if (b <= a && !(v.duration > 0)) return { ok: false, msg: 'Recherche impossible (direct ?)', unsupported: true };
        if (!isFinite(val)) return { ok: false, msg: 'Valeur invalide' };
        const to = clamp(m.cmd === 'seek' ? val : v.currentTime + val, a, Math.max(a, (isFinite(v.duration) ? Math.min(b, v.duration - 0.25) : b)));
        v.currentTime = to; return { ok: true, msg: m.cmd === 'seek' ? 'Position ' + Math.round(to) + ' s' : (val > 0 ? '+' : '') + val + ' s' };
      }
      case 'volume': if (!isFinite(val)) return { ok: false, msg: 'Valeur invalide' };
        return await volumeVerified(v, clamp(val, 0, 1));
      case 'mute': v.muted = !v.muted; return { ok: true, msg: v.muted ? 'Lecteur muet' : 'Son du lecteur rétabli' };
      case 'rate': if (![0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].includes(val)) return { ok: false, msg: 'Vitesse invalide' };
        v.playbackRate = val; return { ok: v.playbackRate === val, msg: 'Vitesse ×' + val };
    }
    return { ok: false, msg: 'Commande inconnue' };
  }

  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !m || typeof m !== 'object') return;
    if (m.type === 'report') { if (m.a) forceA = true; lastSent = ''; flush(); reply({ ok: true }); return; }
    if (m.type === 'profile') { profile = m.profile || profile; adapterCache.ts = 0; return; }
    if (m.type !== 'cmd') return;
    exec(m).then(r => { report(true); reply(r); }, e => reply({ ok: false, msg: String(e) }));
    return true;
  });

  // ---------- Profil local (détection des serveurs auto-hébergés par marqueurs de page) ----------
  function detectMarkers(list) {
    for (const p of list || []) {
      const d = p.detect || {};
      for (const [attr, name, val] of d.meta || []) {
        const el = document.querySelector(`meta[${attr}="${name}"]`);
        if (el && (el.getAttribute('content') || '').toLowerCase().includes(val.toLowerCase())) return p.id;
      }
      if (TOP && (d.title || []).some(t => document.title.trim() === t)) return p.id;
      for (const s of d.selectors || []) { try { if (document.querySelector(s)) return p.id; } catch (e) {} }
    }
    return null;
  }
  function start() {
    if (started) return; started = true;
    try {
      chrome.runtime.sendMessage({ type: 'hello', host: location.hostname, scheme: location.protocol.replace(':', ''), top: TOP }, r => {
        void chrome.runtime.lastError;
        if (!r) { profile = { id: 'generic', name: '', capabilities: {} }; return; }
        profile = r.profile;
        if (profile.id === 'generic' && r.detectable) {
          const id = detectMarkers(r.detectable);
          if (id) send({ type: 'detected', id });
        }
        scan(); report(true);
      });
    } catch (e) { dead = true; }
  }

  // ---------- Boucle légère ----------
  // Lecture en cours : rapport toutes les 1 s ; vidéo présente : 5 s ; aucune vidéo : simple recherche toutes les 5 s.
  let tickN = 0;
  setInterval(() => {
    if (dead) return;
    tickN++;
    if (location.href !== lastHref) { lastHref = location.href; adapterCache.ts = 0; scan(); report(true); return; }  // navigation SPA
    const playing = [...tracked].some(v => !v.paused && !v.ended);
    if (playing) { report(false); if (tickN % 5 === 0) scan(); return; }
    if (tickN % 5 === 0) { scan(); if (tracked.size || (TOP && (forceA || (profile && profile.id !== 'generic')))) report(false); }
  }, 1000);
  document.addEventListener('visibilitychange', () => report(true));
  window.addEventListener('pagehide', () => send({ type: 'bye' }));
  window.addEventListener('popstate', () => setTimeout(() => report(true), 300));

  start();
  scan();
})();
