function show(r) {
  const ok = r && r.connected;
  document.getElementById('dot').className = 'dot ' + (ok ? 'ok' : 'err');
  document.getElementById('txt').textContent = ok ? `Connectée à BedRemote (port ${r.port})`
    : r && r.pending ? 'En attente : autorisez cette extension dans BedRemote (Appareils)' : 'BedRemote introuvable sur ce PC';
  const info = [];
  if (r && r.access === 'none') info.push('Aucun site autorisé : cliquez sur « Autoriser des sites ».');
  if (r && ok) info.push(r.players ? `${r.players} lecteur(s) détecté(s)${r.sites.length ? ' : ' + r.sites.join(', ') : ''}.` : 'Aucune vidéo détectée pour le moment.');
  else if (r && !r.pending) info.push('Lancez BedRemote sur ce PC. La connexion se fait automatiquement.');
  document.getElementById('info').textContent = info.join(' ');
  document.getElementById('grant').style.display = r && r.access !== 'all' ? '' : 'none';
}
function ask() { chrome.runtime.sendMessage({ type: 'status' }, r => { void chrome.runtime.lastError; show(r); }); }
document.getElementById('grant').onclick = () => chrome.runtime.openOptionsPage();
ask(); setTimeout(ask, 1500); setTimeout(ask, 4000);
