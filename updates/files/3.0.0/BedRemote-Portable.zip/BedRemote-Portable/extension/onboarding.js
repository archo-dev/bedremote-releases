async function refresh() {
  const p = await chrome.permissions.getAll();
  const o = (p.origins || []).filter(x => !x.startsWith('http://127.0.0.1/'));
  const all = o.some(x => x === '<all_urls>' || x === '*://*/*');
  const st = document.getElementById('st');
  st.textContent = all ? 'accès accordé à tous les sites ✓' : o.length ? `accès accordé à ${o.length} site(s)` : 'aucun site autorisé pour le moment';
  st.className = o.length ? 'ok' : 'warn';
  document.getElementById('list').textContent = all ? '' : o.join(' · ');
}
document.getElementById('all').onclick = async () => {
  await chrome.permissions.request({ origins: ['<all_urls>'] }).catch(() => false);
  refresh();
};
document.getElementById('one').onclick = async () => {
  let h = document.getElementById('site').value.trim().replace(/^https?:\/\//, '').split('/')[0].toLowerCase();
  if (!/^[a-z0-9.-]+(:\d+)?$/.test(h)) return;
  await chrome.permissions.request({ origins: [`*://${h.split(':')[0]}/*`] }).catch(() => false);
  refresh();
};
refresh();
